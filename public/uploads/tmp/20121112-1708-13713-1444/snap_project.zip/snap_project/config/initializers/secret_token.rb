# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
SnapProject::Application.config.secret_token = 'de3ce5ad11a3bea87a0b2c64ad7a6439dd9e3378777a905b3ea9968b3fc1f1be1898d441e43a0dffe03d74e934a1eaf98432bc9b1a802ef278cfe745ca559746'
