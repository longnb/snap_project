module BoximagesHelper
end
